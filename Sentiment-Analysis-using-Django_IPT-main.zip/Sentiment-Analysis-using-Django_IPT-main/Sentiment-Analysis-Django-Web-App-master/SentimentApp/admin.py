from django.contrib import admin
from .models import SentimentModel

# Register your models here.
admin.site.register(SentimentModel)